﻿namespace IC4_KSS_BackToSchool
{
    partial class BackToSchoolShoppingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BackToSchoolShoppingForm));
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.pensPictureBox = new System.Windows.Forms.PictureBox();
            this.backpackPictureBox = new System.Windows.Forms.PictureBox();
            this.notebookPictureBox = new System.Windows.Forms.PictureBox();
            this.bindersPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cartTotalLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.freeShippingLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pensPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backpackPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notebookPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindersPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(121, 325);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 0;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(329, 325);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pensPictureBox
            // 
            this.pensPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("pensPictureBox.Image")));
            this.pensPictureBox.Location = new System.Drawing.Point(21, 43);
            this.pensPictureBox.Name = "pensPictureBox";
            this.pensPictureBox.Size = new System.Drawing.Size(101, 121);
            this.pensPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pensPictureBox.TabIndex = 2;
            this.pensPictureBox.TabStop = false;
            this.pensPictureBox.Click += new System.EventHandler(this.pensPictureBox_Click);
            // 
            // backpackPictureBox
            // 
            this.backpackPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("backpackPictureBox.Image")));
            this.backpackPictureBox.Location = new System.Drawing.Point(155, 43);
            this.backpackPictureBox.Name = "backpackPictureBox";
            this.backpackPictureBox.Size = new System.Drawing.Size(102, 121);
            this.backpackPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backpackPictureBox.TabIndex = 3;
            this.backpackPictureBox.TabStop = false;
            this.backpackPictureBox.Click += new System.EventHandler(this.backpackPictureBox_Click);
            // 
            // notebookPictureBox
            // 
            this.notebookPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("notebookPictureBox.Image")));
            this.notebookPictureBox.Location = new System.Drawing.Point(286, 43);
            this.notebookPictureBox.Name = "notebookPictureBox";
            this.notebookPictureBox.Size = new System.Drawing.Size(100, 121);
            this.notebookPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.notebookPictureBox.TabIndex = 4;
            this.notebookPictureBox.TabStop = false;
            this.notebookPictureBox.Click += new System.EventHandler(this.notebookPictureBox_Click);
            // 
            // bindersPictureBox
            // 
            this.bindersPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("bindersPictureBox.Image")));
            this.bindersPictureBox.Location = new System.Drawing.Point(419, 43);
            this.bindersPictureBox.Name = "bindersPictureBox";
            this.bindersPictureBox.Size = new System.Drawing.Size(108, 121);
            this.bindersPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bindersPictureBox.TabIndex = 5;
            this.bindersPictureBox.TabStop = false;
            this.bindersPictureBox.Click += new System.EventHandler(this.bindersPictureBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(168, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "**Click On An Item To Add It To The Cart**";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Pens (8-pack)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(182, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Backpack";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(311, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Notebook";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(453, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Binders";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "$8.81";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(194, 188);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "$25.94";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(326, 188);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "$1.10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(460, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "$7.11";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(134, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Shopping Cart Total:";
            // 
            // cartTotalLabel
            // 
            this.cartTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cartTotalLabel.Location = new System.Drawing.Point(338, 233);
            this.cartTotalLabel.Name = "cartTotalLabel";
            this.cartTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.cartTotalLabel.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(59, 271);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(192, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Does Order Qualify For Free* Shipping?";
            // 
            // freeShippingLabel
            // 
            this.freeShippingLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.freeShippingLabel.Location = new System.Drawing.Point(338, 270);
            this.freeShippingLabel.Name = "freeShippingLabel";
            this.freeShippingLabel.Size = new System.Drawing.Size(100, 23);
            this.freeShippingLabel.TabIndex = 18;
            // 
            // BackToSchoolShoppingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 372);
            this.Controls.Add(this.freeShippingLabel);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cartTotalLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bindersPictureBox);
            this.Controls.Add(this.notebookPictureBox);
            this.Controls.Add(this.backpackPictureBox);
            this.Controls.Add(this.pensPictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Name = "BackToSchoolShoppingForm";
            this.Text = "Back To School Shopping";
            ((System.ComponentModel.ISupportInitialize)(this.pensPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backpackPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notebookPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindersPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox pensPictureBox;
        private System.Windows.Forms.PictureBox backpackPictureBox;
        private System.Windows.Forms.PictureBox notebookPictureBox;
        private System.Windows.Forms.PictureBox bindersPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label cartTotalLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label freeShippingLabel;
    }
}

