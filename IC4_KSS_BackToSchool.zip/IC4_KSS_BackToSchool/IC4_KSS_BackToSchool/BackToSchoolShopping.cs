﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC4_KSS_BackToSchool
{
    public partial class BackToSchoolShoppingForm : Form
    {
        decimal cartTotal = 0m;
        const decimal PENS_PRICE = 8.81m;
        const decimal BACKPACK_PRICE = 25.94m;
        const decimal NOTEBOOK_PRICE = 1.10m;
        const decimal BINDERS_PRICE = 7.11m;
        const decimal FREE_SHIPPING = 35m;
        public BackToSchoolShoppingForm()
        {
            InitializeComponent();
        }

        private void pensPictureBox_Click(object sender, EventArgs e)
        {
            //process: add 8.81m to the cartTotal
            cartTotal = PENS_PRICE + cartTotal;
            //display
            cartTotalLabel.Text = cartTotal.ToString("C");
            //if
            if (cartTotal >= FREE_SHIPPING)
            {
                freeShippingLabel.Text = "Yes!";
                freeShippingLabel.ForeColor = Color.Green;
            }
            else
            {
                freeShippingLabel.Text = "No :(";
                freeShippingLabel.ForeColor = Color.Red;
            }
        }

        private void backpackPictureBox_Click(object sender, EventArgs e)
        {
            //process 25.94 + cartTotal
            cartTotal = BACKPACK_PRICE + cartTotal;
            //display
            cartTotalLabel.Text = cartTotal.ToString("C");
            //if
            if (cartTotal >= FREE_SHIPPING)
            {
                freeShippingLabel.Text = "Yes!";
                freeShippingLabel.ForeColor = Color.Green;
            }
            else
            {
                freeShippingLabel.Text = "No :(";
                freeShippingLabel.ForeColor = Color.Red;
            }
        }

        private void notebookPictureBox_Click(object sender, EventArgs e)
        {
            //process
             cartTotal = NOTEBOOK_PRICE + cartTotal;
            //display
            cartTotalLabel.Text = cartTotal.ToString("C");
            //if
            if (cartTotal >= FREE_SHIPPING)
            {
                freeShippingLabel.Text = "Yes!";
                freeShippingLabel.ForeColor = Color.Green;
            }
            else
            {
                freeShippingLabel.Text = "No :(";
                freeShippingLabel.ForeColor = Color.Red;
            }
        }

        private void bindersPictureBox_Click(object sender, EventArgs e)
        {
            //process
             cartTotal = BINDERS_PRICE + cartTotal;
            //display
            cartTotalLabel.Text = cartTotal.ToString("C");
            //if
            if (cartTotal >= FREE_SHIPPING)
            {
                freeShippingLabel.Text = "Yes!";
                freeShippingLabel.ForeColor = Color.Green;
            }
            else
            {
                freeShippingLabel.Text = "No :(";
                freeShippingLabel.ForeColor = Color.Red;
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            cartTotalLabel.Text = "";
            freeShippingLabel.Text = "";

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
